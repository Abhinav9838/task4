# Task-4-LWS
Task Description 📄

🔅 Task 4.1
📌 Create image by yourself Using Python Code 

🔅 Task 4.2
📌 Take 2 image crop some part of both image and swap it. 

🔅 Task 4.3
📌 Take 2 image and combine it to form single image. For example collage 

BLOG LINK OF ABOVE TASKS IN DETAIL - https://sachinjoshi72.medium.com/image-processing-using-opencv-and-numpy-in-python-a2c07eb14a78
